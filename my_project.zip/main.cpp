#include "GameEngine.h"

int main() {
    GameEngine engine;
    engine.run();
    return 0;
}

