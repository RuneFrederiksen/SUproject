# SUproject
Til portfolio i software udvikling 

Spillet ligger i bin mappen 

Første gang man køre spillet vil det automatisk generate en database
hvis dette fejler ligger der en fil i bin/ som kan lave databasen.
Filen hedder Create_database.txt

Den nuværende database.db indeholder tre spil, så man kan teste analysefunktionen
uden at skulle spille spillet flere gange.
